SPELTALE FONT
by Indieground Design © 2023
V.1.0


_____________________________________________________________________________


This font is free for PERSONAL USE ONLY.

If you would like to use it commercially, you can buy the license from https://indieground.net/product/speltale-font/

Thank you.


_____________________________________________________________________________


support@indieground.net
https://indieground.net

